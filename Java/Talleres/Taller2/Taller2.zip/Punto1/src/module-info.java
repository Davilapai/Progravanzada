module Punto2 {
}